clc
close all;
clear all;

image = imread('a3.jpg');
imageOriginal = image;
image = rgb2gray(image);
imshow(image);
template = imread('q1small.jpg');
template = rgb2gray(template);
image = im2double(image);
template = im2double(template);
[h, w] = size(template);

finder1 = normxcorr2(template, image);
figure;
imshow(mat2gray(finder1));
maximum = max(finder1(:));
disp(maximum);
scale = 0;
img = image;

while maximum<0.9
    img = impyramid(img, 'reduce');
    disp(size(img));
    finder = normxcorr2(template, img);
    disp(size(finder));
    maximum = max(finder(:));
    scale = scale+1;
    disp(maximum)
end

[xpeak, ypeak] = find(finder == max(finder(:)));
xpeak1 = (xpeak-h/2)*(2^(scale));
ypeak1 = (ypeak-w/2)*(2^(scale));

width = w*(2^(scale));
height = h*(2^(scale));
imageOriginal = insertShape(imageOriginal, 'Rectangle', [ypeak1-width/2 xpeak1-height/2 width height],'LineWidth',3, 'color', 'red');


finder(xpeak, ypeak) = 0;
[xpeak, ypeak] = find(finder == max(finder(:)));
finder(xpeak, ypeak) = 0;
[xpeak, ypeak] = find(finder == max(finder(:)));
xpeak1 = (xpeak-h/2)*(2^(scale));
ypeak1 = (ypeak-w/2)*(2^(scale));
height = h*(2^(scale));
imageOriginal = insertShape(imageOriginal, 'Rectangle', [ypeak1-width/2 xpeak1-height/2 width height],'LineWidth',3, 'color', 'red');
figure;
imshow(imageOriginal)



