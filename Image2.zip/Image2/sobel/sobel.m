clc
close all
im = imread('lines.png');
imshow(im);
%grayIm = rgb2gray(im);
grayIm = im;
imshow(grayIm);

sobelX = [-1, -2, -1; 
           0, 0, 0; 
           1, 2, 1];
sobelY = [-1, 0, 1;
          -2, 0, 2;
          -1, 0, 1];
sobel45 = [0, 1, 2;
          -1, 0, 1;
          -2, -1, 0];

[h, w] = size(grayIm);
outputImX = zeros(h, w);
outputImY = zeros(h, w);
output45 = zeros(h, w);
grayIm = im2double(grayIm);

for i = 2:h-1
    for j = 2:w-1
        outputImX(i,j) = (sum(sum(grayIm(i-1:i+1, j-1:j+1).*sobelX)))/4;
    end
end
figure;
outputImX = mat2gray(outputImX);
imshow(outputImX);
imwrite(outputImX, 'outputImX.jpg')

for i = 2:h-1
    for j = 2:w-1
        outputImY(i,j) = (sum(sum(grayIm(i-1:i+1, j-1:j+1).*sobelY)))/4;
    end
end
figure;
outputImY = mat2gray(outputImY);
imshow(outputImY);
imwrite(outputImY, 'outputImY.jpg')

for i = 2:h-1
    for j = 2:w-1
        output45(i,j) = (sum(sum(grayIm(i-1:i+1, j-1:j+1).*sobel45)))/4;
    end
end
figure;
output45 = mat2gray(output45);
imshow(output45);
imwrite(output45, 'output45.jpg')
