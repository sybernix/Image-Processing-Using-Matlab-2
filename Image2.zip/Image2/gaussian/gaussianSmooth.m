clc
close all
im = imread('thumbX.png');
imshow(im);
grayIm = rgb2gray(im);
grayIm2 = imnoise(grayIm, 'gaussian', 0.0, 0.2);
imwrite(grayIm2, 'noisyImg.jpg');
grayIm = imnoise(grayIm, 'gaussian', 0.0, 0.01);
imshow(grayIm);

laplacian = [-1, -1, -1;
             -1, 8, -1;
             -1, -1, -1];
laplacianOfGaussian = [0, 0, 1, 0, 0;
                       0, 1, 2, 1, 0;
                       1, 2, -16, 2, 1;
                       0, 1, 2, 1, 0;
                       0, 0, 1, 0, 0];

[h, w] = size(grayIm);
outputImX = zeros(h, w);
outputImY = zeros(h, w);
output45 = zeros(h, w);
grayIm = im2double(grayIm);
grayIm2 = im2double(grayIm2);

for i = 2:h-1
    for j = 2:w-1
        outputImX(i,j) = (sum(sum(grayIm2(i-1:i+1, j-1:j+1).*laplacian)))/4;
    end
end
figure;
outputImX = mat2gray(outputImX);
imshow(outputImX);
imwrite(outputImX, 'laplacian.jpg')

for i = 3:h-2
    for j = 3:w-2
        outputImX(i,j) = (sum(sum(grayIm(i-2:i+2, j-2:j+2).*laplacianOfGaussian)))/4;
    end
end
figure;
outputImX = mat2gray(outputImX);
imshow(outputImX);
imwrite(outputImX, 'LofG.jpg')