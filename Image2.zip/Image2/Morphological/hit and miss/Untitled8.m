clc;
close all;
clear all;

im1 = im2double(imread('hitmiss.png'));
im2 = im2double(imread('hitmiss2.png'));

im = im1.*im2;

[xpeak, ypeak] = find(im == max(im(:)));
im = insertShape(im,'circle',[ypeak xpeak 50], 'LineWidth',5, 'color', 'red');

im = mat2gray(im);
%imwrite(im, 'output1.png');
ori = im2double(imread('paa.tif'));
ori = insertShape(ori,'circle',[ypeak xpeak 50], 'LineWidth',5, 'color', 'red');
imshow(ori)