image = imread('finger.tif');
imshow(image);

struct = [1,1,1;1,1,1;1,1,1];
centerh=2;
centerw=2;
[sh,sw] = size(struct);
structvalue = sum(sum(struct));

figure;
imshow(struct);

[ih,iw]=size(image);

topmargin = centerh-1;
bottommargin = sh-centerh;
leftmargin= centerw-1;
rightmargin = sw-centerw;

temp = zeros(topmargin+ih+bottommargin,leftmargin+iw+rightmargin);
temp(topmargin+1:topmargin+ih,leftmargin+1:leftmargin+iw)=image;

output = zeros(ih,iw);

for k = 1:ih
    for l= 1:iw
        tempextract = temp(k:k+sh-1,l:l+sw-1);
        value = sum(sum(tempextract.*struct));
        if value== structvalue
            output(k,l) = 1;
        else
            output(k,l)= 0;
        end
    end
end

figure;
imshow(output);