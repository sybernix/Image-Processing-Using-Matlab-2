clc;
close all;

% testImage = imread('circles.tif');
% imshow(testImage);
% 
% structuringElement = strel('square', 30);
% 
% dilatedImage = imdilate(testImage, structuringElement);
% 
% figure;
% imshow(dilatedImage);
% figure;
% imshow(mat2gray(structuringElement.Neighborhood))

% testImage = [0, 0, 0, 0, 0, 0, 0, 0;
%              0, 0, 0, 0, 0, 0, 0, 0;
%              0, 0, 0, 1, 1, 0, 0, 0;
%              0, 0, 0, 0, 0, 1, 0, 0;
%              0, 0, 0, 0, 0, 0, 0, 0;
%              0, 0, 0, 0, 0, 0, 0, 0;];
% 
% structuringElement = [0, 1, 0;
%                       1, 1, 0;
%                       0, 0, 0];

testImage = im2double(imread('circles.tif'));
figure;
imshow(testImage);
structuringElement = strel('square', 20);
structuringElement = structuringElement.Neighborhood;
                  
structuringElement = rot90(structuringElement,2);
[SEHeight, SEWidth] = size(structuringElement);
[testImageHeight, testImageWidth] = size(testImage);
outputImage = zeros(testImageHeight, testImageWidth);

if mod(SEWidth, 2) == 0
    widthBufferLeft = (SEWidth/2) -1;
    widthBufferRight = SEWidth/2;
else
    widthBufferLeft = floor(SEWidth/2);
    widthBufferRight = floor(SEWidth/2);
end

if mod(SEHeight, 2) == 0
    heightBufferUp = (SEHeight/2) -1;
    heightBufferDown = SEHeight/2;
else
    heightBufferUp = floor(SEHeight/2);
    heightBufferDown = floor(SEHeight/2);
end

row = zeros(1,testImageWidth);

for i=1:heightBufferUp
    testImage = [row; testImage];
end

for i=1:heightBufferDown
    testImage = [testImage; row];
end

[testImageHeight, ~] = size(testImage);
column = zeros(testImageHeight,1);

for i=1:widthBufferLeft
    testImage = horzcat(column, testImage);
end

for i=1:widthBufferRight
    testImage = horzcat(testImage, column);
end

[testImageHeight, testImageWidth] = size(testImage);

for i=heightBufferUp+1:testImageHeight-heightBufferDown
    for j=widthBufferLeft+1:testImageWidth-widthBufferRight
        testImageExtract = testImage(i-heightBufferUp:i+heightBufferDown, j-widthBufferLeft:j+widthBufferRight);
        incidence = sum(sum(testImageExtract.*structuringElement));
        if incidence>0
            outputImage(i-heightBufferUp, j-widthBufferLeft) = 1;
        end
    end
end

outputImage=mat2gray(outputImage);
imwrite(outputImage, 'outputImage.png')
figure;
imshow(outputImage);







