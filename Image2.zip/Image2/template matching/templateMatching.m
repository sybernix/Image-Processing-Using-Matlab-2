clc
close all;

image = imread('a3.jpg');
imageOriginal = image;
image = rgb2gray(image);
imshow(image);
template = imread('q1.ppm');
template = rgb2gray(template);
imshow(template);

[templateHeight, templateWidth] = size(template);
[imageHeight, imageWidth] = size(image);
template = im2double(template);
image = im2double(image);
templatePixelCount = templateHeight*templateWidth;
templateAverage = sum(sum(template))/templatePixelCount;
template = template-templateAverage;
templateStandardDeviation = std2(template);
finder = zeros(imageHeight, imageWidth);

if mod(templateWidth, 2) == 0
    widthBufferLeft = (templateWidth/2) -1;
    widthBufferRight = templateWidth/2;
else
    widthBufferLeft = floor(templateWidth/2);
    widthBufferRight = floor(templateWidth/2);
end

if mod(templateHeight, 2) == 0
    heightBufferUp = (templateHeight/2) -1;
    heightBufferDown = templateHeight/2;
else
    heightBufferUp = floor(templateHeight/2);
    heightBufferDown = floor(templateHeight/2);
end

for i = heightBufferUp+1:imageHeight-(heightBufferDown)
    for j = widthBufferLeft+1:imageWidth-(widthBufferRight)
        imageExtract = image(i-heightBufferUp:i+heightBufferDown, j-widthBufferLeft:j+widthBufferRight);
        extractAverage = sum(sum(imageExtract));
        extractAverage = extractAverage/templatePixelCount;
        extractStandardDeviation = std2(imageExtract);
        imageExtract = imageExtract-extractAverage;
        testFinder = sum(sum((imageExtract.*template)))/templatePixelCount;
        finder(i,j) = testFinder;
    end
end

[xpeak, ypeak] = find(finder == max(finder(:)));
disp(xpeak);
disp(ypeak);
xpeakHalf = ceil(xpeak - templateHeight/2);
ypeakHalf = ceil(ypeak - templateWidth/2);
imageOriginal = insertShape(imageOriginal, 'Rectangle', [ypeakHalf, xpeakHalf, templateWidth templateHeight],'LineWidth',3, 'color', 'red');
imwrite(imageOriginal, 'foundMatch1.jpg');
figure;
imshow(imageOriginal);

figure;
finder = mat2gray(finder);
%finder = insertShape(finder, 'Rectangle', [ypeakHalf, xpeakHalf, templateWidth templateHeight], 'color', 'white');
imwrite(finder, 'NormalizedCrossCorrelation.jpg');
imshow(finder);

finder(xpeak, ypeak) = 0;
[xpeak, ypeak] = find(finder == max(finder(:)));
disp(xpeak);
disp(ypeak);
xpeakHalf = ceil(xpeak - templateHeight/2);
ypeakHalf = ceil(ypeak - templateWidth/2);
imageOriginal = insertShape(imageOriginal, 'Rectangle', [ypeakHalf, xpeakHalf, templateWidth templateHeight],'LineWidth',3, 'color', 'red');
imwrite(imageOriginal, 'foundMatch2.jpg');
figure;
imshow(imageOriginal);








